package com.infinite.VMC1.Repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infinite.VMC1.entity.Complaints;
import com.infinite.VMC1.entity.VMCdata;
@Repository
public class VMCimpls implements VMCDao{
	@Autowired
	SessionFactory sfactory;
	public List<Complaints> getAllComplaints() {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		List<Complaints> ls = session.createQuery("from complaints").list();
		return ls;
	}

	public Complaints getComplaint(int id) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		Complaints complaint = session.get(Complaints.class,id);
		return complaint;
	}

	public void toinsert(Complaints complaint) {
		// TODO Auto-generated method stub
		Session session=this.sfactory.getCurrentSession();
		session.save(complaint);
	}

	public void login(VMCdata vmcdata) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		session.save(vmcdata);
	}

}
