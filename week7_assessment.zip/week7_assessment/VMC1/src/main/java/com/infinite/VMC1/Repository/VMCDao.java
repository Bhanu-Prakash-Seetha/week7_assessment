package com.infinite.VMC1.Repository;

import java.util.List;

import com.infinite.VMC1.entity.Complaints;
import com.infinite.VMC1.entity.VMCdata;

public interface VMCDao {
	public List<Complaints> getAllComplaints();
	public Complaints getComplaint(int id);
	public void toinsert(Complaints complaint);
	public void login(VMCdata vmcdata);
}
