package com.infinite.VMC1.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.VMC1.Service.Serviceimpls;
import com.infinite.VMC1.entity.Complaints;
import com.infinite.VMC1.entity.VMCdata;
@Controller
public class VMCController {
	@Autowired
	Serviceimpls simpls;
	
	
	public void setSimpls(Serviceimpls simpls) {
		this.simpls = simpls;
	}
	@RequestMapping(value="/",method=RequestMethod.GET,headers = "Accept=application/json")
	public String gotoHome(){
		return "redirect:/getlogin";
	}
	@RequestMapping(value="/getlogin",method=RequestMethod.GET)
	public String showlogin(Model model){
		model.addAttribute("vmcdata", new VMCdata());
		//model.addAttribute("ListOfComplaints", simpls.getAllComplaints());
		return "loginpage";
	}
	@RequestMapping(value="/getlogin",method=RequestMethod.POST,headers = "Accept=application/json")
	public String login(@Valid @ModelAttribute("vmcdata") VMCdata vmcdata,BindingResult result){
		if(result.hasErrors()){
			System.out.println(result);
			return "loginpage";
		}else if(vmcdata != null){
			simpls.login(vmcdata);
		}
		return "complaintpage";
	}
	@RequestMapping(value="/getAllComplaints",method=RequestMethod.GET)
	public String getAllComplaints(Model model){
		model.addAttribute("complaintdata", new Complaints());
		model.addAttribute("ListOfComplaints", simpls.getAllComplaints());
		return "complaintpage";
	}
	@RequestMapping(value="/getComplaint/{id}",method=RequestMethod.GET,headers = "Accept=application/json")
	public Complaints getComplaint(@PathVariable int id){
		return simpls.getComplaint(id);
	}
	@RequestMapping(value="/adddata",method=RequestMethod.POST)
	public String adddata(Complaints complaint){
		simpls.toinsert(complaint);
		return "complaintpage";
	}
}
