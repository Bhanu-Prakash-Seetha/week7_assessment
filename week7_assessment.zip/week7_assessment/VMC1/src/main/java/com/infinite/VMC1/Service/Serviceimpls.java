package com.infinite.VMC1.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infinite.VMC1.Repository.VMCimpls;
import com.infinite.VMC1.entity.Complaints;
import com.infinite.VMC1.entity.VMCdata;
@Service
public class Serviceimpls implements VMCService{
	@Autowired VMCimpls vmcimpls;
	
	@Transactional
	public List<Complaints> getAllComplaints() {
		// TODO Auto-generated method stub
		return vmcimpls.getAllComplaints();
	}
	@Transactional
	public Complaints getComplaint(int id) {
		// TODO Auto-generated method stub
		return vmcimpls.getComplaint(id);
	}
	@Transactional
	public void toinsert(Complaints complaint) {
		// TODO Auto-generated method stub
		vmcimpls.toinsert(complaint);
	}
	@Transactional
	public void login(VMCdata vmcdata) {
		// TODO Auto-generated method stub
		vmcimpls.login(vmcdata);
	}

}
