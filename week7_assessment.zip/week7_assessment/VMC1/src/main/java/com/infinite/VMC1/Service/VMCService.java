package com.infinite.VMC1.Service;

import java.util.List;

import com.infinite.VMC1.entity.Complaints;
import com.infinite.VMC1.entity.VMCdata;
public interface VMCService {
	public List<Complaints> getAllComplaints();
	public Complaints getComplaint(int id);
	public void toinsert(Complaints complaint);
	public void login(VMCdata vmcdata);
}
